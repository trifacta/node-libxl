This example uses ot4xb library for Xbase++.

Please download and install ot4xb.dll library for Xbase++ here:

http://www.xbwin.com/

